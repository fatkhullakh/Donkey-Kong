#include "Player.h"

	bool Player::collisionBarrel(Player& player, item barrel[]) {
		for (int i = 8; i >= 0; i--) {
			if (!barrel[i].isCollected()) {
				if ((this->getXPos() > barrel[i].getXPos() - (barrel[i].getSurface()->clip_rect.w) / 2) && (this->getXPos() < barrel[i].getXPos() + (barrel[i].getSurface()->clip_rect.w) / 2) &&
					(this->getYPos() > barrel[i].getYPos() - (barrel[i].getSurface()->clip_rect.h) / 2) && (this->getYPos() < barrel[i].getYPos() + (barrel[i].getSurface()->clip_rect.h / 2))) {
					return true;
				}
			}
		}
		return false;
	}

	bool Player::jumpingBonus(Player& player, item barrel[]) {
		for (int i = 8; i >= 0; i--) {
			if (!barrel[i].isCollected()) {
				if ((this->getXPos() > barrel[i].getXPos() - (barrel[i].getSurface()->clip_rect.w) / 2) && (this->getXPos() < barrel[i].getXPos() + (barrel[i].getSurface()->clip_rect.w) / 2) &&
					(this->getYPos() < barrel[i].getYPos() - (barrel[i].getSurface()->clip_rect.h) / 2) && (this->getYPos() > barrel[i].getYPos() - 75)) {
					barrel[i].markAsCollected();
					return true;
				}
			}
		}
		return false;
	}

	bool Player::collisionBonus(Player& player, item bonus[]) {
		for (int i = 8; i >= 0; i--) {
			if (!bonus[i].isCollected()) {
				if ((this->getXPos() > bonus[i].getXPos() - (bonus[i].getSurface()->clip_rect.w) / 2) && (this->getXPos() < bonus[i].getXPos() + (bonus[i].getSurface()->clip_rect.w) / 2) &&
					(this->getYPos() > bonus[i].getYPos() - (bonus[i].getSurface()->clip_rect.h) / 2) && (this->getYPos() < bonus[i].getYPos() + (bonus[i].getSurface()->clip_rect.h / 2))) {
					bonus[i].markAsCollected();
					return true;
				}
			}
		}
		return false;
	}


	void Player::updateJump(float gravity, item platform[], int numPlatforms) {
		if (isJumping) {
			setYPos(getYPos() - verticalVelocity);
			verticalVelocity -= gravity;

			int playerBottom = getYPos() + (getSurface()->clip_rect.h / 2);
			// Check for collision with platforms during descent
			for (int i = platform_numbers - 1; i >= 0; i--) {
				int platformTop = platform[i].getYPos() - (platform[i].getSurface()->clip_rect.h / 2);
				// Check if the player is within the horizontal bounds of the platform
				if (getXPos() >= platform[i].getXPos() - (platform[i].getSurface()->clip_rect.w / 2) &&
					getXPos() <= platform[i].getXPos() + (platform[i].getSurface()->clip_rect.w / 2)) {
					// Check if the player has landed on the platform
					if (verticalVelocity < -10 && playerBottom <= platformTop) {
						setYPos(platformTop - (getSurface()->clip_rect.h / 2)); // Adjust Y position to top of the platform
						isJumping = false;
						verticalVelocity = 0.0f;
						break; // Exit the loop as we have landed
					}
				}
			}
			// If we are not colliding with any platform, check for the ground level
			if (isJumping && getYPos() >= 446) {
				setYPos(446);
				isJumping = false;
				verticalVelocity = 0.0f;
			}
		}
	}
	bool Player::getIsJumping() {
		return isJumping;
	}
	bool Player::isOnSolidGround(Player& player, item floor[], item platform[], item ladder[], int numFloors, int numPlatforms) {
		// Get the bottom edge of the player
		int playerBottom = player.getYPos() + (player.getSurface()->clip_rect.h / 2);

		// Check against each floor
		for (int i = 0; i < numFloors; i++) {
			int floorTop = floor[i].getYPos() - (floor[i].getSurface()->clip_rect.h / 2);
			if (playerBottom == floorTop && player.getXPos() >= floor[i].getXPos() - (floor[i].getSurface()->clip_rect.w / 2) &&
				player.getXPos() <= floor[i].getXPos() + (floor[i].getSurface()->clip_rect.w / 2)) {
				return true;
			}
		}


		// Check against each platform
		for (int i = 0; i < numPlatforms; i++) {
			int platformTop = platform[i].getYPos() - (platform[i].getSurface()->clip_rect.h / 2);
			if (playerBottom == platformTop && player.getXPos() >= platform[i].getXPos() - (platform[i].getSurface()->clip_rect.w / 2) &&
				player.getXPos() <= platform[i].getXPos() + (platform[i].getSurface()->clip_rect.w / 2)) {
				return true;
			}
		}
		// Check against each ladder
		for (int i = 3; i >= 0; i--) {
			if ((this->getXPos() > ladder[i].getXPos() - ladder[i].getSurface()->clip_rect.w / 2) && (this->getXPos() < ladder[i].getXPos() + ladder[i].getSurface()->clip_rect.w / 2) &&
				(this->getYPos() < ladder[i].getYPos() + 14 && this->getYPos() > ladder[i].getYPos() + 4 - ladder[i].getSurface()->clip_rect.h))
				return false;
		}
		// Not on solid ground
		return false;
	}
	void Player::startJump(float initialVelocity) {
		if (!isJumping) {
			isJumping = true;
			verticalVelocity = initialVelocity;
		}
	}
	void Player::move() {
		setXPos(1);
	}

	void Player::moveRight() {
		// check if he can move to the right

		setXPos(getXPos() + 15);
	}

	void Player::moveLeft() {
		setXPos(getXPos() - 15);
	}

	void Player::moveUp() {
		setYPos(getYPos() - 3);

	}



	void Player::moveDown() {
		setYPos(getYPos() + 3);
	}

	bool Player::isLevelCompleted(item Door[1]) {
		if ((this->getXPos() > Door[0].getXPos() - Door[0].getSurface()->clip_rect.w / 2) && (this->getXPos() < Door[0].getXPos() + Door[0].getSurface()->clip_rect.w / 2) &&
			((this->getYPos() < Door[0].getYPos() + Door[0].getSurface()->clip_rect.h / 2) && (this->getYPos() > Door[0].getYPos() - Door[0].getSurface()->clip_rect.h / 2))) {
			return true;
		}
		return false;
	}

	bool Player::onPLatform(item platform[], item floor[], item ladder[]) {
		bool brbalo = false;

		for (int i = 0; i < floor_numbers; i++) {
			if ((floor[i].getXPos() - 1 - (floor[i].getSurface()->clip_rect.w) / 2 < this->getXPos() && this->getXPos() < floor[i].getXPos() + 1 + (floor[i].getSurface()->clip_rect.w) / 2) &&
				(this->getYPos() + this->getSurface()->clip_rect.h / 2 == floor[i].getYPos() - floor[i].getSurface()->clip_rect.h / 2)) {
				brbalo = true;
			}
		}
		for (int i = platform_numbers - 1; i >= 0; i--) {
			if ((platform[i].getXPos() - 1 - (platform[i].getSurface()->clip_rect.w) / 2 < this->getXPos() && platform[i].getXPos() + (platform[i].getSurface()->clip_rect.w) / 2 > this->getXPos()) &&
				(this->getYPos() + this->getSurface()->clip_rect.h / 2 == platform[i].getYPos() - platform[i].getSurface()->clip_rect.h / 2))
				brbalo = true;
		}

		for (int i = 3; i >= 0; i--) {
			if (((this->getXPos() > ladder[i].getXPos() - (ladder[i].getSurface()->clip_rect.w) / 2) && (this->getXPos() < ladder[i].getXPos() + (ladder[i].getSurface()->clip_rect.w) / 2)) &&
				(this->getYPos() < ladder[i].getYPos() + (ladder[i].getSurface()->clip_rect.h) / 2) && (this->getYPos() + 12 + this->getSurface()->clip_rect.h / 2 > ladder[i].getYPos() - (ladder[i].getSurface()->clip_rect.h) / 2)) {
				brbalo = true;
			}
		}

		return brbalo;
	}
	// TODO
	bool Player::canMove(item ladder[], item floor[], item platform[], int direction) {
		bool hello = false;


		switch (direction) {
		case UP:
			for (int i = 3; i >= 0; i--) {
				if (((this->getXPos() > ladder[i].getXPos() - (ladder[i].getSurface()->clip_rect.w) / 2) && (this->getXPos() < ladder[i].getXPos() + (ladder[i].getSurface()->clip_rect.w) / 2)) &&
					(this->getYPos() < ladder[i].getYPos() + (ladder[i].getSurface()->clip_rect.h) / 2) && (this->getYPos() + 12 + this->getSurface()->clip_rect.h / 2 > ladder[i].getYPos() - (ladder[i].getSurface()->clip_rect.h) / 2)) {
					hello = true;
				}
			}
			break;
		case DOWN:
			for (int i = 3; i >= 0; i--) {
				if (((this->getXPos() > ladder[i].getXPos() - (ladder[i].getSurface()->clip_rect.w) / 2) && (this->getXPos() < ladder[i].getXPos() + (ladder[i].getSurface()->clip_rect.w) / 2)) &&
					(this->getYPos() < ladder[i].getYPos() + 15) && (this->getYPos() > ladder[i].getYPos() - ladder[i].getSurface()->clip_rect.h)) {
					hello = true;
				}
			}
			break;
		case RIGHT:



			for (int i = 0; i < floor_numbers; i++) {
				if ((floor[i].getXPos() - (floor[i].getSurface()->clip_rect.w) / 2 < this->getXPos() < floor[i].getXPos() + (floor[i].getSurface()->clip_rect.w) / 2)) {
					hello = true;
				}
			}
			for (int i = 3; i >= 0; i--) {
				if ((this->getXPos() > ladder[i].getXPos() - ladder[i].getSurface()->clip_rect.w / 2) && (this->getXPos() < ladder[i].getXPos() + ladder[i].getSurface()->clip_rect.w / 2) &&
					(this->getYPos() < ladder[i].getYPos() + 14 && this->getYPos() > ladder[i].getYPos() + 4 - ladder[i].getSurface()->clip_rect.h))
					hello = false;
			}


			break;
		case LEFT:
			for (int i = 0; i < floor_numbers; i++) {
				if ((floor[i].getXPos() - (floor[i].getSurface()->clip_rect.w) / 2 < this->getXPos() < floor[i].getXPos() + (floor[i].getSurface()->clip_rect.w) / 2)) {
					hello = true;
				}
			}
			for (int i = 3; i >= 0; i--) {
				if ((this->getXPos() > ladder[i].getXPos() - ladder[i].getSurface()->clip_rect.w / 2) && (this->getXPos() < ladder[i].getXPos() + ladder[i].getSurface()->clip_rect.w / 2) &&
					(this->getYPos() < ladder[i].getYPos() + 14 && this->getYPos() > ladder[i].getYPos() + 4 - ladder[i].getSurface()->clip_rect.h))
					hello = false;
			}
			break;
		}


		if (hello) {
			switch (direction) {
			case UP:
				if (getYPos() - 5 > 0)
					moveUp();
				break;
			case DOWN:
				if (getYPos() + 5 < SCREEN_HEIGHT)
					moveDown();
				break;
			case RIGHT:
				if (getXPos() + 5 < SCREEN_WIDTH)
					moveRight();
				break;
			case LEFT:
				if (getXPos() - 5 > 0)
					moveLeft();
				break;
			}
		}
		return hello;
	}