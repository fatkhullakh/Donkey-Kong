#pragma once
#ifndef constants_h
#define constanst_h


#define SCREEN_WIDTH	640
#define SCREEN_HEIGHT	480

#define UP 1
#define DOWN 2
#define RIGHT 3
#define LEFT 4

const int platform_numbers = 20; 
const int ladder_numbers = 4; 
const int floor_numbers = 8; 
const float initialJumpVelocity = 21.0;

const float gravity = 2; // Adjust this value based on desired gravity effectd


extern char nickname[100]; // Array to store the nickname
extern int nicknameLength; // Length of the current nickname
extern bool isEnteringName; // Flag to check if we are in "entering nickname" mode
#endif