#pragma once
#include "item.h"

class Player : public item {
public:
	Player() : item() {
		verticalVelocity = 0.0;
		isJumping = false;
		for (int i = 0; i < 9; i++) {
			collectedBonuses[i] = false;
		}

	}
	bool isJumping;

	bool collisionBarrel(Player& player, item barrel[]);

	bool jumpingBonus(Player& player, item barrel[]);

	bool collisionBonus(Player& player, item bonus[]);

	void updateJump(float gravity, item platform[], int numPlatforms);
	
	bool getIsJumping();

	bool isOnSolidGround(Player& player, item floor[], item platform[], item ladder[], int numFloors, int numPlatforms);

	void startJump(float initialVelocity);

	void move();

	void moveRight();

	void moveLeft();

	void moveUp();

	void moveDown();

	bool isLevelCompleted(item Door[1]);

	bool onPLatform(item platform[], item floor[], item ladder[]);

	bool canMove(item ladder[], item floor[], item platform[], int direction);

private:
	float verticalVelocity;
	bool collectedBonuses[9];

};