#pragma once
#include  <stdio.h>
#include "constants.h"

extern "C" {
#include"./SDL2-2.0.10/include/SDL.h"
#include"./SDL2-2.0.10/include/SDL_main.h"
}

class item {

public:
	item() : collected(false) {
		pos.x = 0;
		pos.y = 0;
	}

	item(int x, int y) : collected(false) {
		pos.x = x;
		pos.y = y;
	}

	bool isCollected() const {
		return collected;
	}

	void markAsCollected() {
		collected = true;
	}

	void markAsNotCollected() {
		collected = false;
	}

	SDL_Surface* getSurface() {
		return surface;
	}

	int getLife() {
		return lifeLevel;
	}

	void setLife(int LifeLevel) {
		this->lifeLevel = LifeLevel;
	}

	int getXPos() {
		return pos.x;
	}

	void setXPos(int xPos) {
		this->pos.x = xPos;
	}

	int getYPos() {
		return pos.y;
	}

	void setYPos(int yPos) {
		this->pos.y = yPos;
	}

	void setPos(int x, int y) {
		pos.x = x;
		pos.y = y;
	}

	int loadingImageSurface(char* urlPic) {
		surface = SDL_LoadBMP(urlPic);

		if (surface == NULL) {
			printf("SDL_LoadBMP(%s) error: %s\n", urlPic, SDL_GetError());
			return -1;
		}

		return 1;
	}

protected:
	int s;

private:

	bool collected;
	SDL_Rect pos;
	SDL_Surface* surface;
	int lifeLevel = 3;
};