﻿#define _USE_MATH_DEFINES
#include<math.h>
#include<stdio.h>
#include<string.h>
#include <fstream>
#include "constants.h"
#include "item.h"
#include "Player.h"

extern "C" {
#include"./SDL2-2.0.10/include/SDL.h"
#include"./SDL2-2.0.10/include/SDL_main.h"
}

void DrawString(SDL_Surface* screen, int x, int y, const char* text,
	SDL_Surface* charset) {
	int px, py, c;
	SDL_Rect s, d;
	s.w = 8;
	s.h = 8;
	d.w = 8;
	d.h = 8;
	while (*text) {
		c = *text & 255;
		px = (c % 16) * 8;
		py = (c / 16) * 8;
		s.x = px;
		s.y = py;
		d.x = x;
		d.y = y;
		SDL_BlitSurface(charset, &s, screen, &d);
		x += 8;
		text++;
	};
};

void DrawSurface(SDL_Surface* screen, SDL_Surface* sprite, int x, int y) {
	SDL_Rect dest;
	dest.x = x - sprite->w / 2;
	dest.y = y - sprite->h / 2;
	dest.w = sprite->w;
	dest.h = sprite->h;
	SDL_BlitSurface(sprite, NULL, screen, &dest);
};

// draw a single pixel
void DrawPixel(SDL_Surface* surface, int x, int y, Uint32 color) {
	int bpp = surface->format->BytesPerPixel;
	Uint8* p = (Uint8*)surface->pixels + y * surface->pitch + x * bpp;
	*(Uint32*)p = color;
};

// draw a vertical (when dx = 0, dy = 1) or horizontal (when dx = 1, dy = 0) line
void DrawLine(SDL_Surface* screen, int x, int y, int l, int dx, int dy, Uint32 color) {
	for (int i = 0; i < l; i++) {
		DrawPixel(screen, x, y, color);
		x += dx;
		y += dy;
	};
};

// draw a rectangle of size l by k
void DrawRectangle(SDL_Surface* screen, int x, int y, int l, int k, Uint32 outlineColor, Uint32 fillColor) {
	int i;
	DrawLine(screen, x, y, k, 0, 1, outlineColor);
	DrawLine(screen, x + l - 1, y, k, 0, 1, outlineColor);
	DrawLine(screen, x, y, l, 1, 0, outlineColor);
	DrawLine(screen, x, y + k - 1, l, 1, 0, outlineColor);
	for (i = y + 1; i < y + k - 1; i++)
		DrawLine(screen, x + 1, i, l - 2, 1, 0, fillColor);
}

void level1(SDL_Surface* screen, item Floor[], item Platform[], item Ladder[], item Kong[1], item Door[1], item Barrel[3], item Bonus[3], item Life[], Player p) {
	for (int i = 0, j = 44, k = 475; i < 8; i++, j += 88) {
		Floor[i].setPos(j, k);
		DrawSurface(screen, Floor[i].getSurface(), Floor[i].getXPos(), Floor[i].getYPos());
	}
	for (int i = 0, j = 540, k = 385; i < 5; i++, j -= 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	for (int i = 5, j = 100, k = 295; i < 10; i++, j += 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	for (int i = 10, j = 540, k = 205; i < 15; i++, j -= 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	for (int i = 15, j = 100, k = 115; i < 20; i++, j += 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	Ladder[0].setPos(540, 430);
	DrawSurface(screen, Ladder[0].getSurface(), Ladder[0].getXPos(), Ladder[0].getYPos());
	Ladder[1].setPos(100, 340);
	DrawSurface(screen, Ladder[1].getSurface(), Ladder[1].getXPos(), Ladder[1].getYPos());
	Ladder[2].setPos(540, 250);
	DrawSurface(screen, Ladder[2].getSurface(), Ladder[2].getXPos(), Ladder[2].getYPos());
	Ladder[3].setPos(100, 160);
	DrawSurface(screen, Ladder[3].getSurface(), Ladder[3].getXPos(), Ladder[3].getYPos());


	DrawSurface(screen, p.getSurface(), p.getXPos(), p.getYPos());

	Door[0].setPos(400, 83);
	DrawSurface(screen, Door[0].getSurface(), Door[0].getXPos(), Door[0].getYPos());

	Barrel[0].setPos(320, 457);
	Barrel[1].setPos(160, 367);
	Barrel[2].setPos(480, 277);
	for (int i = 0; i < 3; i++) {
		if (!Barrel[i].isCollected()) {
			DrawSurface(screen, Barrel[i].getSurface(), Barrel[i].getXPos(), Barrel[i].getYPos());
		}
	}

	Kong[0].setPos(600, 77);
	DrawSurface(screen, Kong[0].getSurface(), Kong[0].getXPos(), Kong[0].getYPos());

	Bonus[0].setPos(50, 365);
	Bonus[1].setPos(600, 275);
	Bonus[2].setPos(50, 185);

	for (int i = 0; i < 3; i++) {
		// Check if the bonus has been collected
		if (!Bonus[i].isCollected()) {
			// Draw the bonus if it's not collected
			DrawSurface(screen, Bonus[i].getSurface(), Bonus[i].getXPos(), Bonus[i].getYPos());
		}

	}

	Life[0].setPos(20, 55);
	Life[1].setPos(40, 55);
	Life[2].setPos(60, 55);

	for (int i = 0; i < p.getLife(); i++) {
		DrawSurface(screen, Life[i].getSurface(), Life[i].getXPos(), Life[i].getYPos());
	}

}

void level2(SDL_Surface* screen, item Floor[], item Platform[], item Ladder[], item Kong[1], item Door[1], item Barrel[3], item Bonus[3], item Life[], Player p) {
	for (int i = 0, j = 44, k = 475; i < 8; i++, j += 88) {
		Floor[i].setPos(j, k);
		DrawSurface(screen, Floor[i].getSurface(), Floor[i].getXPos(), Floor[i].getYPos());
	}

	for (int i = 0, j = 171, k = 385; i < 5; i++, j += 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	for (int i = 5, j = 238, k = 295; i < 9; i++, j += 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	for (int i = 9, j = 305, k = 205; i < 12; i++, j += 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	for (int i = 12, j = 372, k = 115; i < 15; i++, j += 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	Ladder[0].setPos(119, 430);
	DrawSurface(screen, Ladder[0].getSurface(), Ladder[0].getXPos(), Ladder[0].getYPos());
	Ladder[1].setPos(186, 340);
	DrawSurface(screen, Ladder[1].getSurface(), Ladder[1].getXPos(), Ladder[1].getYPos());
	Ladder[2].setPos(253, 250);
	DrawSurface(screen, Ladder[2].getSurface(), Ladder[2].getXPos(), Ladder[2].getYPos());
	Ladder[3].setPos(320, 160);
	DrawSurface(screen, Ladder[3].getSurface(), Ladder[3].getXPos(), Ladder[3].getYPos());

	Barrel[3].setPos(0, 0);
	Barrel[4].setPos(350, 367);
	Barrel[5].setPos(480, 277);
	for (int i = 3; i < 6; i++) {
		if (!Barrel[i].isCollected()) {
			DrawSurface(screen, Barrel[i].getSurface(), Barrel[i].getXPos(), Barrel[i].getYPos());
		}
	}

	Kong[0].setPos(600, 77);
	DrawSurface(screen, Kong[0].getSurface(), Kong[0].getXPos(), Kong[0].getYPos());

	DrawSurface(screen, p.getSurface(), p.getXPos(), p.getYPos());

	Door[0].setPos(400, 83);
	DrawSurface(screen, Door[0].getSurface(), Door[0].getXPos(), Door[0].getYPos());

	Bonus[3].setPos(600, 365);

	Bonus[4].setPos(600, 275);

	Bonus[5].setPos(600, 185);

	for (int i = 3; i < 6; i++) {
		// Check if the bonus has been collected
		if (!Bonus[i].isCollected()) {
			// Draw the bonus if it's not collected
			DrawSurface(screen, Bonus[i].getSurface(), Bonus[i].getXPos(), Bonus[i].getYPos());
		}
	}

	Life[0].setPos(20, 55);
	Life[1].setPos(40, 55);
	Life[2].setPos(60, 55);

	for (int i = 0; i < p.getLife(); i++) {
		DrawSurface(screen, Life[i].getSurface(), Life[i].getXPos(), Life[i].getYPos());
	}
}

void level3(SDL_Surface* screen, item Floor[], item Platform[], item Ladder[], item Kong[1], item Door[1], item Barrel[], item Bonus[], item Life[], Player p) {
	for (int i = 0, j = 44, k = 475; i < 8; i++, j += 88) {
		Floor[i].setPos(j, k);
		DrawSurface(screen, Floor[i].getSurface(), Floor[i].getXPos(), Floor[i].getYPos());
	}

	for (int i = 0, j = 67, k = 385; i < 3; i++, j += 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	for (int i = 3, j = 67, k = 295; i < 5; i++, j += 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	Platform[5].setPos(67, 205);
	DrawSurface(screen, Platform[5].getSurface(), Platform[5].getXPos(), Platform[5].getYPos());

	for (int i = 6, j = 640, k = 385; i < 8; i++, j -= 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	for (int i = 9, j = 640, k = 295; i < 12; i++, j -= 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	for (int i = 12, j = 640, k = 205; i < 16; i++, j -= 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}

	Platform[16].setPos(0, 115);
	DrawSurface(screen, Platform[16].getSurface(), Platform[16].getXPos(), Platform[16].getYPos());

	for (int i = 17, j = 640, k = 115; i < 20; i++, j -= 134) {
		Platform[i].setPos(j, k);
		DrawSurface(screen, Platform[i].getSurface(), Platform[i].getXPos(), Platform[i].getYPos());
	}



	Ladder[0].setPos(100, 430);
	DrawSurface(screen, Ladder[0].getSurface(), Ladder[0].getXPos(), Ladder[0].getYPos());
	Ladder[1].setPos(540, 340);
	DrawSurface(screen, Ladder[1].getSurface(), Ladder[1].getXPos(), Ladder[1].getYPos());
	Ladder[2].setPos(100, 250);
	DrawSurface(screen, Ladder[2].getSurface(), Ladder[2].getXPos(), Ladder[2].getYPos());
	Ladder[3].setPos(540, 160);
	DrawSurface(screen, Ladder[3].getSurface(), Ladder[3].getXPos(), Ladder[3].getYPos());


	Kong[0].setPos(35, 77);
	DrawSurface(screen, Kong[0].getSurface(), Kong[0].getXPos(), Kong[0].getYPos());

	Barrel[6].setPos(320, 457);
	Barrel[7].setPos(220, 367);
	Barrel[8].setPos(231, 187);
	for (int i = 6; i < 9; i++) {
		if (!Barrel[i].isCollected()) {
			DrawSurface(screen, Barrel[i].getSurface(), Barrel[i].getXPos(), Barrel[i].getYPos());
		}
	}

	DrawSurface(screen, p.getSurface(), p.getXPos(), p.getYPos());


	Door[0].setPos(400, 83);
	DrawSurface(screen, Door[0].getSurface(), Door[0].getXPos(), Door[0].getYPos());


	Bonus[6].setPos(600, 365);

	Bonus[7].setPos(50, 275);

	Bonus[8].setPos(600, 185);

	for (int i = 6; i < 9; i++) {
		// Check if the bonus has been collected
		if (!Bonus[i].isCollected()) {
			// Draw the bonus if it's not collected
			DrawSurface(screen, Bonus[i].getSurface(), Bonus[i].getXPos(), Bonus[i].getYPos());
		}
	}

	Life[0].setPos(620, 55);
	Life[1].setPos(600, 55);
	Life[2].setPos(580, 55);

	for (int i = 0; i < p.getLife(); i++) {
		DrawSurface(screen, Life[i].getSurface(), Life[i].getXPos(), Life[i].getYPos());
	}
}

void saveGame(const char* filename, const char* nickname, int playerScore, int currentLevel) {
	FILE* outFile = fopen(filename, "a"); // Appending to the file
	if (!outFile) {
		printf("Error opening file for writing!\n");
		return;
	}

	fprintf(outFile, "%s %d %d\n", nickname, playerScore, currentLevel);

	fclose(outFile);
}

void showResults(SDL_Surface* screen, SDL_Surface* charset) {
	FILE* inFile = fopen("savegame.txt", "r");
	if (!inFile) {
		printf("Error opening file for reading.\n");
		return;
	}

	char line[128];
	int y = 50; 
	while (fgets(line, sizeof(line), inFile)) {
		DrawString(screen, 100, y, line, charset); 
		y += 20; // Move down for the next line
	}

	fclose(inFile);
}



// main
#ifdef __cplusplus
extern "C"
#endif
int main(int argc, char** argv) {

	int quit, frames, rc, t1, t2;
	double fpsTimer, fps, etiSpeed, delta, distance, worldTime;
	bool menu, options, continueMenu;
	SDL_Event event;
	SDL_Surface* screen, * charset;
	SDL_Surface* eti;
	SDL_Texture* scrtex;
	SDL_Window* window;
	SDL_Renderer* renderer;
	
	frames = 0;
	fpsTimer = 0;
	fps = 0;
	quit = 0;
	menu = 1;
	options = 0;
	worldTime = 0;
	continueMenu = 0;
	int currentLevel = 1;
	bool levelCompleted = false;
	bool showResultsFlag = false;
	int playerScore = 0;

	char nickname[100]; 
	int nicknameLength = 0;
	bool isEnteringName = false; 

	Player p;
	p.loadingImageSurface("Pics/Player.bmp");
	p.setXPos(50);
	p.setYPos(446);
	item Ladder[10];
	item Floor[10];
	item Platform[20];
	item Kong[1];
	item Door[1];
	item Barrel[9];
	item Bonus[9];
	item Life[3];


	for (int i = 0; i < 10; i++) Ladder[i].loadingImageSurface("Pics/Ladder.bmp");
	for (int i = 0; i < 20; i++) Platform[i].loadingImageSurface("Pics/Platform.bmp");
	for (int i = 0; i < 10; i++) Floor[i].loadingImageSurface("Pics/Floor.bmp");
	for (int i = 0; i < 9; i++) Barrel[i].loadingImageSurface("Pics/Barrel.bmp");
	for (int i = 0; i < 9; i++) Bonus[i].loadingImageSurface("Pics/Bonus.bmp");
	for (int i = 0; i < 3; i++) Life[i].loadingImageSurface("Pics/Lifes.bmp");
	Kong[0].loadingImageSurface("Pics/Kong.bmp");
	Door[0].loadingImageSurface("Pics/Door.bmp");

	if (SDL_Init(SDL_INIT_EVERYTHING) != 0) {
		printf("SDL_Init error: %s\n", SDL_GetError());
		return 1;
	}

	rc = SDL_CreateWindowAndRenderer(SCREEN_WIDTH, SCREEN_HEIGHT, 0,
		&window, &renderer);
	if (rc != 0) {
		SDL_Quit();
		printf("SDL_CreateWindowAndRenderer error: %s\n", SDL_GetError());
		return 1;
	};

	SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "linear");
	SDL_RenderSetLogicalSize(renderer, SCREEN_WIDTH, SCREEN_HEIGHT);
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

	SDL_SetWindowTitle(window, "Szablon do zdania drugiego 2017");

	screen = SDL_CreateRGBSurface(0, SCREEN_WIDTH, SCREEN_HEIGHT, 32,
		0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);

	scrtex = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_ARGB8888,
		SDL_TEXTUREACCESS_STREAMING,
		SCREEN_WIDTH, SCREEN_HEIGHT);


	SDL_ShowCursor(SDL_ENABLE);

	// wczytanie obrazka cs8x8.bmp
	charset = SDL_LoadBMP("Pics/cs8x8.bmp");
	if (charset == NULL) {
		printf("SDL_LoadBMP(cs8x8.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	};
	SDL_SetColorKey(charset, true, 0x000000);


	eti = SDL_LoadBMP("Pics/eti.bmp");
	if (eti == NULL) {
		printf("SDL_LoadBMP(eti.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	};

	char text[128];
	int black = SDL_MapRGB(screen->format, 0x00, 0x00, 0x00);
	int green = SDL_MapRGB(screen->format, 0x00, 0xFF, 0x00);
	int red = SDL_MapRGB(screen->format, 0xFF, 0x00, 0x00);
	int blue = SDL_MapRGB(screen->format, 0x11, 0x11, 0xCC);

	t1 = SDL_GetTicks();

	frames = 0;
	fpsTimer = 0;
	fps = 0;
	quit = 0;
	worldTime = 0;
	distance = 0;
	etiSpeed = 1;
	bool exit = false;


	while (!quit) {

		while (menu && !quit)
		{
			DrawRectangle(screen, 4, 4, SCREEN_WIDTH - 8, SCREEN_HEIGHT - 8, red, blue);
			DrawSurface(screen, eti, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 - 150);
			sprintf(text, "Welcome to Donkey Kong game");
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, screen->h / 2 - 30, text, charset);
			sprintf(text, "Press 1, 2 or 3 for levels:");
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, screen->h / 2, text, charset);
			sprintf(text, "Press S to start the game");
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, screen->h / 2 + 30, text, charset);
			sprintf(text, "Press R to check results");
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, screen->h / 2 + 60, text, charset);
			sprintf(text, "Press Esc to quit the game");
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, screen->h / 2 + 90, text, charset);
			sprintf(text, "Press Backspace to save the game");
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, screen->h / 2 + 120, text, charset);
			sprintf(text, "Press H to read");
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, screen->h / 2 + 150, text, charset);

			while (SDL_PollEvent(&event)) {
				switch (event.type) {
				case SDL_KEYDOWN:
					if (event.key.keysym.sym == SDLK_ESCAPE) quit = 1;
					else if (event.key.keysym.sym == SDLK_1)
					{
						currentLevel = 1;
						menu = 0;
					}
					else if (event.key.keysym.sym == SDLK_2)
					{
						currentLevel = 2;
						menu = 0;
					}
					else if (event.key.keysym.sym == SDLK_3)
					{
						currentLevel = 3;
						menu = 0;
					}
					else if (event.key.keysym.sym == SDLK_s)
					{
						menu = 0;
					}
					else if (event.key.keysym.sym == SDLK_r)
					{
						showResultsFlag = !showResultsFlag;
					}
					else if (event.key.keysym.sym == SDLK_h)
					{
					}
					break;
				case SDL_KEYUP:
					break;
				case SDL_QUIT:
					quit = 1;
					break;
				default:
					break;
				};
			};

			if (showResultsFlag) {
				showResults(screen, charset);
			}

			SDL_UpdateTexture(scrtex, NULL, screen->pixels, screen->pitch);
			SDL_RenderCopy(renderer, scrtex, NULL, NULL);
			SDL_RenderPresent(renderer);
		}

		while (!menu && !quit && !continueMenu) {
			t2 = SDL_GetTicks();

			delta = (t2 - t1) * 0.001;
			t1 = t2;

			worldTime += delta;

			distance += etiSpeed * delta;

			SDL_FillRect(screen, NULL, black);

			fpsTimer += delta;
			if (fpsTimer > 0.5) {
				fps = frames * 2;
				frames = 0;
				fpsTimer -= 0.5;
			};

			DrawRectangle(screen, 4, 4, SCREEN_WIDTH - 8, 36, red, blue);
			sprintf(text, "Esc - exit, elapsed time = %.1lf s  %.0lf frames / s", worldTime, fps);
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, 10, text, charset);
			sprintf(text, "Total points: %d", playerScore);
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, 26, text, charset);
			
			

			if (levelCompleted == false) {
				// Update the current level
				switch (currentLevel) {
				case 1:
					level1(screen, Floor, Platform, Ladder, Kong, Door, Barrel, Bonus, Life, p);
					break;
				case 2:
					level2(screen, Floor, Platform, Ladder, Kong, Door, Barrel, Bonus, Life, p);
					break;
				case 3:
					level3(screen, Floor, Platform, Ladder, Kong, Door, Barrel, Bonus, Life, p);
					break;
					// Add more levels as needed
				}
			}
			else {
				
				currentLevel++;
				playerScore += 100;
				levelCompleted = false;

				
				if (currentLevel > 4) {
					quit = true;
				}
			}

			SDL_UpdateTexture(scrtex, NULL, screen->pixels, screen->pitch);
			SDL_RenderCopy(renderer, scrtex, NULL, NULL);
			SDL_RenderPresent(renderer);

			while (SDL_PollEvent(&event)) {
				switch (event.type) {
				case SDL_KEYDOWN:
					switch (event.key.keysym.sym)
					{
					case SDLK_UP:
						p.canMove(Ladder, Floor, Platform, UP);
						break;
					case SDLK_DOWN:
						p.canMove(Ladder, Floor, Platform, DOWN);
						break;
					case SDLK_RIGHT:
						p.canMove(Ladder, Floor, Platform, RIGHT);
						break;
					case SDLK_LEFT:
						p.canMove(Ladder, Floor, Platform, LEFT);
						break;
					case SDLK_SPACE:
						if (!p.getIsJumping() && p.isOnSolidGround(p, Floor, Platform, Ladder, floor_numbers, platform_numbers)) {
							p.startJump(initialJumpVelocity);
						}
						break;
					case SDLK_n:
						switch (currentLevel) {
						case 1:
							currentLevel = 1;
							break;
						case 2:
							currentLevel = 2;
							break;
						case 3:
							currentLevel = 3;
							break;
						}

						worldTime = 0.0;
						p.setXPos(50);
						p.setYPos(446);
						p.setLife(3);
						break;
					case SDLK_ESCAPE:
						quit = 1;
					default:
						break;
					}
					break;
				};
			};

			

			if (p.collisionBonus(p, Bonus) || p.jumpingBonus(p, Barrel)) {
				playerScore += 50;
				
			}

			if (p.collisionBarrel(p, Barrel) == true) {
				p.setLife(p.getLife() - 1);
				p.setPos(50, 446);
			}


			if (p.onPLatform(Platform, Floor, Ladder) == false) {
				for (int i = 0; i < 4; i++) {
					p.setYPos(p.getYPos() + i);
				}
			}
			p.updateJump(gravity, Platform, platform_numbers);

			if (p.isLevelCompleted(Door)) {
				levelCompleted = true;
				p.setPos(50, 446);
			}

			if (p.getLife() == 0 || currentLevel > 3) {
				continueMenu = true;
			}
			SDL_RenderPresent(renderer);
			SDL_Delay(25);
		}

		while (continueMenu && !quit)
		{
			DrawRectangle(screen, 4, 4, SCREEN_WIDTH - 8, SCREEN_HEIGHT - 8, red, blue);
			DrawSurface(screen, eti, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 - 150);
			sprintf(text, "To save the game press 'Backspace' or press ESC to exit, or press n for menu");
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, screen->h / 2 - 30, text, charset);
			sprintf(text, "Your score is %d", playerScore);
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, screen->h / 2, text, charset);
			while (SDL_PollEvent(&event)) {
				switch (event.type) {
				case SDL_KEYDOWN:
					if (event.key.keysym.sym == SDLK_BACKSPACE && !isEnteringName) {
						isEnteringName = true;
						SDL_StartTextInput(); 
						memset(nickname, 0, sizeof(nickname)); // Clear the nickname array
						nicknameLength = 0;
						continue;
					}
					else if (isEnteringName && event.key.keysym.sym == SDLK_RETURN) {
						isEnteringName = false;
						SDL_StopTextInput();
						saveGame("savegame.txt", nickname, playerScore, currentLevel);
					}
					else if (event.key.keysym.sym == SDLK_ESCAPE) quit = 1;
					else if (event.key.keysym.sym == SDLK_n) {
						menu = 1;
						continueMenu = 0;
					}
					break;
				case SDL_TEXTINPUT:
					if (isEnteringName && nicknameLength < sizeof(nickname) - 1) {
						strcat(nickname, event.text.text);
						nicknameLength++;
					}
					break;
				case SDL_QUIT:
					quit = 1;
					break;
				default:
					break;
				}
			}

			if (isEnteringName) {
				char displayText[120];
				sprintf(displayText, "Nickname %s", nickname);
				DrawString(screen, 250, 340, displayText, charset);
			}

			SDL_UpdateTexture(scrtex, NULL, screen->pixels, screen->pitch);
			SDL_RenderCopy(renderer, scrtex, NULL, NULL);
			SDL_RenderPresent(renderer);
		} 


	};

	// freeing all surfaces
	SDL_FreeSurface(charset);
	SDL_FreeSurface(screen);
	SDL_DestroyTexture(scrtex);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);

	SDL_Quit();
	return 0;
};